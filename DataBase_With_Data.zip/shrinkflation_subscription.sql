-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: shrinkflation
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `subscription`
--

DROP TABLE IF EXISTS `subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscription` (
  `SubscriptionID` varchar(16) NOT NULL,
  `CustomerID` varchar(16) NOT NULL,
  `Features` varchar(16) NOT NULL,
  `SubscriptionLevel` varchar(16) NOT NULL,
  `SubscriptionPrice` decimal(10,2) NOT NULL,
  `SubscriptionDate` date DEFAULT NULL,
  PRIMARY KEY (`SubscriptionID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `subscription_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `customer` (`CustomerID`),
  CONSTRAINT `subscription_chk_1` CHECK ((`Features` in (_utf8mb4'A',_utf8mb4'B',_utf8mb4'C',_utf8mb4'D'))),
  CONSTRAINT `subscription_chk_2` CHECK ((`SubscriptionLevel` in (_utf8mb4'Gold',_utf8mb4'Silver',_utf8mb4'Iron'))),
  CONSTRAINT `subscription_chk_3` CHECK ((`SubscriptionPrice` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscription`
--

LOCK TABLES `subscription` WRITE;
/*!40000 ALTER TABLE `subscription` DISABLE KEYS */;
INSERT INTO `subscription` VALUES ('00b088307367c0f9','2f72319caec5d639','B','Gold',36.77,'2020-08-08'),('0cdae352de56aed3','dbaa8bd25e06cc64','A','Gold',11.70,'2023-07-10'),('22fb3c6454faac89','dbaa8bd25e06cc64','D','Silver',31.13,'2021-01-27'),('3204fc25e61b182c','9e8486cdd435beda','B','Silver',95.86,'2020-02-18'),('35c39495c2fed54e','9e8486cdd435beda','C','Silver',22.78,'2022-07-03'),('53414ff1b618d9d1','3079e3991f94d1b3','B','Silver',85.85,'2021-06-14'),('660812d1c427e21d','033f7f6121501ae9','C','Gold',37.92,'2022-08-03'),('8aa0cae957ef67b6','a2b14389d02e3cd6','D','Iron',74.53,'2021-04-06'),('92ae56dfb2659930','e90d3fa207c52d08','A','Gold',68.25,'2023-08-25'),('a63653a8f4585434','5ce4d191fd14ac85','B','Silver',18.78,'2022-06-23'),('be1f12c2bdc2bc40','5db2d12c8faad9e4','B','Iron',51.71,'2022-05-09'),('dc4f12e7d48e6e3e','2f72319caec5d639','D','Iron',92.22,'2022-02-08'),('e08bba5380d9541b','81162e1ef3d93f96','C','Iron',75.21,'2021-08-14'),('e4bea76d5b04bc1a','5ce4d191fd14ac85','A','Gold',25.00,'2020-08-07'),('f99f5f7eff094dd6','2f72319caec5d639','D','Silver',94.54,'2021-12-25');
/*!40000 ALTER TABLE `subscription` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 22:54:58
