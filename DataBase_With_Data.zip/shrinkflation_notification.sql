-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: shrinkflation
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `NotificationID` varchar(16) NOT NULL,
  `EventID` varchar(16) NOT NULL,
  `MessageContent` varchar(250) DEFAULT NULL,
  `MessageTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`NotificationID`),
  KEY `EventID` (`EventID`),
  CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`EventID`) REFERENCES `shrinkflation_event` (`EventID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
INSERT INTO `notification` VALUES ('150f629d91042e19','280ceb2f47942aeb','Notification message 3','2024-03-24 22:08:35'),('34c75873ec1bebea','1e1b3ec9a5e3cffb','Notification message 14','2024-03-24 22:08:35'),('45f1c30fe48be13b','938429be5d31dc91','Notification message 12','2024-03-24 22:08:35'),('4707d8e1511a3d30','24c1dcde10a01503','Notification message 0','2024-03-24 22:08:35'),('4bd844aac23efbce','06ef389db0e8b3e2','Notification message 2','2024-03-24 22:08:35'),('531c3d49a4b0d25e','1e1b3ec9a5e3cffb','Notification message 6','2024-03-24 22:08:35'),('962588e176c0bbdc','938429be5d31dc91','Notification message 1','2024-03-24 22:08:35'),('a4abf98f5b376d53','938429be5d31dc91','Notification message 7','2024-03-24 22:08:35'),('aa8480503ef4c498','8efe7273c54bc81d','Notification message 4','2024-03-24 22:08:35'),('c4aaf5d3704efff9','6b99e9356b967418','Notification message 13','2024-03-24 22:08:35'),('c7969086c174e3b7','daee4c473df022b3','Notification message 9','2024-03-24 22:08:35'),('d4073aa7bbd6f301','f4aa19c9a4f9cb11','Notification message 11','2024-03-24 22:08:35'),('ef22decdb5ec88fe','8c47d80f898fa232','Notification message 10','2024-03-24 22:08:35'),('f5083f8acb336ffa','8efe7273c54bc81d','Notification message 5','2024-03-24 22:08:35'),('fd9343409404c22a','8efe7273c54bc81d','Notification message 8','2024-03-24 22:08:35');
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 22:54:59
