-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: shrinkflation
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `shrinkflation_metric`
--

DROP TABLE IF EXISTS `shrinkflation_metric`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shrinkflation_metric` (
  `ShrinkflationMetricID` varchar(16) NOT NULL,
  `ChangeWeight` decimal(10,2) DEFAULT NULL,
  `ChangeCount` int DEFAULT NULL,
  `ChangePrice` decimal(10,2) DEFAULT NULL,
  `PercentChangePrice` decimal(5,2) DEFAULT NULL,
  `PercentChangeCount` decimal(5,2) DEFAULT NULL,
  `PercentChangeWeight` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`ShrinkflationMetricID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shrinkflation_metric`
--

LOCK TABLES `shrinkflation_metric` WRITE;
/*!40000 ALTER TABLE `shrinkflation_metric` DISABLE KEYS */;
INSERT INTO `shrinkflation_metric` VALUES ('1270ca36a4084e36',0.16,-10,-0.31,0.00,-0.10,0.00),('26d0e91d3818f091',0.26,-6,-3.24,-0.03,-0.06,0.00),('376b4c889410025a',0.41,9,3.30,0.03,0.09,0.00),('40a302e574e4efd0',-0.13,-5,1.76,0.02,-0.05,0.00),('5f955b7e90801551',-0.31,10,-2.76,-0.03,0.10,0.00),('77a379dc66036d6a',-0.16,-4,0.84,0.01,-0.04,0.00),('79fb6199e0d9a888',-0.02,-4,4.96,0.05,-0.04,0.00),('95132e71b9f2146f',0.00,-10,-1.26,-0.01,-0.10,0.00),('9765983e32135efc',-0.29,6,0.15,0.00,0.06,0.00),('afc13348d2c945e8',-0.06,9,4.17,0.04,0.09,0.00),('c40cf251a6d0a712',-0.32,-6,4.20,0.04,-0.06,0.00),('d93864abbf1a3b1c',0.32,8,0.60,0.01,0.08,0.00),('f3d304430844ded7',-0.44,-6,-4.50,-0.04,-0.06,0.00),('f8e59b7032dea7b4',-0.34,-9,4.30,0.04,-0.09,0.00),('fe0a98f9dbe8fb0b',0.31,-4,3.99,0.04,-0.04,0.00);
/*!40000 ALTER TABLE `shrinkflation_metric` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 22:54:57
