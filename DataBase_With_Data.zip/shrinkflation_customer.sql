-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: shrinkflation
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `CustomerID` varchar(16) NOT NULL,
  `Username` varchar(16) NOT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(32) NOT NULL,
  `UserType` varchar(10) DEFAULT NULL,
  `CreateTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CustomerID`),
  CONSTRAINT `customer_chk_1` CHECK ((`UserType` in (_utf8mb4'FreeUser',_utf8mb4'PaidUser')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('033f7f6121501ae9','user3','user3@example.com','819b0643d6b89dc9b579fdfc9094f28e','PaidUser','2024-03-24 21:21:16'),('236fd0fa27a9769b','user11','user11@example.com','1e5c2776cf544e213c3d279c40719643','FreeUser','2024-03-24 21:21:16'),('2f72319caec5d639','user9','user9@example.com','5d69dd95ac183c9643780ed7027d128a','FreeUser','2024-03-24 21:21:16'),('3079e3991f94d1b3','user8','user8@example.com','b25ef06be3b6948c0bc431da46c2c738','FreeUser','2024-03-24 21:21:16'),('55feb130be438e68','user4','user4@example.com','34cc93ece0ba9e3f6f235d4af979b16c','FreeUser','2024-03-24 21:21:16'),('5ce4d191fd14ac85','user2','user2@example.com','6cb75f652a9b52798eb6cf2201057c73','PaidUser','2024-03-24 21:21:16'),('5db2d12c8faad9e4','user0','user0@example.com','305e4f55ce823e111a46a9d500bcb86c','FreeUser','2024-03-24 21:21:16'),('7fde19c6179474de','user14','user14@example.com','8ee736784ce419bd16554ed5677ff35b','PaidUser','2024-03-24 21:21:16'),('81162e1ef3d93f96','user7','user7@example.com','00cdb7bb942cf6b290ceb97d6aca64a3','PaidUser','2024-03-24 21:21:16'),('9e8486cdd435beda','user5','user5@example.com','db0edd04aaac4506f7edab03ac855d56','PaidUser','2024-03-24 21:21:16'),('a18135715c760761','user12','user12@example.com','c24a542f884e144451f9063b79e7994e','FreeUser','2024-03-24 21:21:16'),('a2b14389d02e3cd6','user10','user10@example.com','87e897e3b54a405da144968b2ca19b45','PaidUser','2024-03-24 21:21:16'),('dbaa8bd25e06cc64','user6','user6@example.com','218dd27aebeccecae69ad8408d9a36bf','PaidUser','2024-03-24 21:21:16'),('e90d3fa207c52d08','user13','user13@example.com','ee684912c7e588d03ccb40f17ed080c9','FreeUser','2024-03-24 21:21:16'),('ffbc4675f864e0e9','user1','user1@example.com','7c6a180b36896a0a8c02787eeafb0e4c','PaidUser','2024-03-24 21:21:16');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 22:54:57
