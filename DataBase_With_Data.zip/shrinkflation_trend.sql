-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: shrinkflation
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `trend`
--

DROP TABLE IF EXISTS `trend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `trend` (
  `TrendID` varchar(16) NOT NULL,
  `ShrinkflationMetricID` varchar(16) NOT NULL,
  `ShrinkflationIndex` decimal(10,2) DEFAULT NULL,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  PRIMARY KEY (`TrendID`),
  KEY `ShrinkflationMetricID` (`ShrinkflationMetricID`),
  CONSTRAINT `trend_ibfk_1` FOREIGN KEY (`ShrinkflationMetricID`) REFERENCES `shrinkflation_metric` (`ShrinkflationMetricID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trend`
--

LOCK TABLES `trend` WRITE;
/*!40000 ALTER TABLE `trend` DISABLE KEYS */;
INSERT INTO `trend` VALUES ('Trend01','f8e59b7032dea7b4',1.50,'2022-01-01','2022-06-30'),('Trend02','5f955b7e90801551',2.00,'2022-02-01','2022-07-31'),('Trend03','40a302e574e4efd0',1.80,'2022-03-01','2022-08-31'),('Trend04','1270ca36a4084e36',1.60,'2022-04-01','2022-09-30'),('Trend05','f3d304430844ded7',2.20,'2022-05-01','2022-10-31'),('Trend06','95132e71b9f2146f',1.70,'2022-06-01','2022-11-30'),('Trend07','9765983e32135efc',2.10,'2022-07-01','2022-12-31'),('Trend08','c40cf251a6d0a712',1.90,'2022-08-01','2023-01-31'),('Trend09','376b4c889410025a',1.40,'2022-09-01','2023-02-28'),('Trend10','fe0a98f9dbe8fb0b',2.30,'2022-10-01','2023-03-31'),('Trend11','d93864abbf1a3b1c',1.20,'2022-11-01','2023-04-30'),('Trend12','26d0e91d3818f091',1.10,'2022-12-01','2023-05-31'),('Trend13','afc13348d2c945e8',2.40,'2023-01-01','2023-06-30'),('Trend14','77a379dc66036d6a',1.30,'2023-02-01','2023-07-31'),('Trend15','79fb6199e0d9a888',2.50,'2023-03-01','2023-08-31');
/*!40000 ALTER TABLE `trend` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-24 22:54:57
